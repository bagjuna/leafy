create function xpath(text, xml) returns xml[]
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.xpath($1, $2, '{}'::pg_catalog.text[])$$;

comment on function xpath(unknown, text, xml) is 'evaluate XPath expression';

alter function xpath(unknown, text, xml) owner to myuser;

