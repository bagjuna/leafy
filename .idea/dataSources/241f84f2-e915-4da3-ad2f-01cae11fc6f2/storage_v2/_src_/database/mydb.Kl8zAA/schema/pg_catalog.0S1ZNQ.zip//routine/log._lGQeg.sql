create function log(numeric) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.log(10, $1)$$;

comment on function log(unknown, numeric) is 'base 10 logarithm';

alter function log(unknown, numeric) owner to myuser;

