create function _pg_interval_type(typid oid, mod integer) returns text
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT
  CASE WHEN $1 IN (1186) /* interval */
           THEN pg_catalog.upper(substring(pg_catalog.format_type($1, $2) from 'interval[()0-9]* #"%#"' for '#'))
       ELSE null
  END$$;

alter function _pg_interval_type(oid, integer) owner to myuser;

