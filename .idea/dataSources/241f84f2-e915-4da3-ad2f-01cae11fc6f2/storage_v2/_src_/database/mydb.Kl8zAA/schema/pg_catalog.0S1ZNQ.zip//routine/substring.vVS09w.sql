create function substring(text, text, text) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.substring($1, pg_catalog.similar_to_escape($2, $3))$$;

comment on function substring(text, text, text) is 'extract text matching SQL regular expression';

alter function substring(text, text, text) owner to myuser;

