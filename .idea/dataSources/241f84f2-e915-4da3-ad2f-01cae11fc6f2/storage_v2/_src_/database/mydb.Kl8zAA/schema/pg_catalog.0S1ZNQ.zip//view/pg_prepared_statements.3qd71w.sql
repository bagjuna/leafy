create view pg_prepared_statements(name, statement, prepare_time, parameter_types, from_sql) as
SELECT p.name,
       p.statement,
       p.prepare_time,
       p.parameter_types,
       p.from_sql
FROM pg_prepared_statement() p(name, statement, prepare_time, parameter_types, from_sql);

alter table pg_prepared_statements
    owner to myuser;

grant select on pg_prepared_statements to public;

